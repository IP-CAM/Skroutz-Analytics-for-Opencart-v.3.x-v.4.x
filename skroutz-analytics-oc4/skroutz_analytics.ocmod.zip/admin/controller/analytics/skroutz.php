<?php

/**
 * Shopflix Analytics
 * @author Prionysis
 * @website https://github.com/Prionysis
 * @version 1.1
 */

namespace Opencart\Admin\Controller\Extension\SkroutzAnalytics\Analytics;

use Opencart\System\Engine\Controller;

class Skroutz extends Controller
{
	public function index()
	{
		$this->load->language('extension/skroutz_analytics/analytics/skroutz');

		$this->document->setTitle($this->language->get('heading_title'));

		// Breadcrumbs
		$data['breadcrumbs'] = [];

		$data['breadcrumbs'][] = [
			'text' => $this->language->get('text_home'),
			'href' => $this->url->link('common/dashboard', 'user_token=' . $this->session->data['user_token'], true)
		];

		$data['breadcrumbs'][] = [
			'text' => $this->language->get('text_extension'),
			'href' => $this->url->link('marketplace/extension', 'user_token=' . $this->session->data['user_token'] . '&type=analytics', true)
		];

		$data['breadcrumbs'][] = [
			'text' => $this->language->get('heading_title'),
			'href' => $this->url->link('extension/skroutz_analytics/analytics/skroutz', 'user_token=' . $this->session->data['user_token'] . '&store_id=' . $this->request->get['store_id'], true)
		];

		// Buttons
		$data['save'] = $this->url->link('extension/skroutz_analytics/analytics/skroutz|save', 'user_token=' . $this->session->data['user_token'] . '&store_id=' . $this->request->get['store_id'], true);
		$data['back'] = $this->url->link('marketplace/extension', 'user_token=' . $this->session->data['user_token'] . '&type=analytics', true);

		// Code
		$data['analytics_skroutz_code'] = $this->model_setting_setting->getValue('analytics_skroutz_code', $this->request->get['store_id']);

		// Status
		$data['analytics_skroutz_status'] = $this->model_setting_setting->getValue('analytics_skroutz_status', $this->request->get['store_id']);

		// Widget
		$data['analytics_skroutz_widget'] = $this->model_setting_setting->getValue('analytics_skroutz_widget', $this->request->get['store_id']);

		// Replace HTML
		$data['analytics_skroutz_replace_html'] = $this->model_setting_setting->getValue('analytics_skroutz_replace_html', $this->request->get['store_id']);

		// Replace Position
		$data['analytics_skroutz_replace_position'] = $this->model_setting_setting->getValue('analytics_skroutz_replace_position', $this->request->get['store_id']);

		$data['header'] = $this->load->controller('common/header');
		$data['column_left'] = $this->load->controller('common/column_left');
		$data['footer'] = $this->load->controller('common/footer');

		$this->response->setOutput($this->load->view('extension/skroutz_analytics/analytics/skroutz', $data));
	}

	protected function save(): void
	{
		$this->load->language('extension/skroutz_analytics/analytics/skroutz');

		$json = [];

		if (!$this->user->hasPermission('modify', 'extension/skroutz_analytics/analytics/skroutz')) {
			$json['error']['warning'] = $this->language->get('error_permission');
		}

		if (empty($this->request->post['analytics_skroutz_code'])) {
			$json['error']['code'] = $this->language->get('error_code');
		}

		if (isset($json['error']) && !isset($json['error']['warning'])) {
			$json['error']['warning'] = $this->language->get('error_warning');
		}

		if (!$json) {
			$this->load->model('setting/setting');

			$this->model_setting_setting->editSetting('analytics_skroutz', $this->request->post, $this->request->get['store_id']);

			$this->session->data['success'] = $this->language->get('text_success');
		}

		$this->response->addHeader('Content-Type: application/json');
		$this->response->setOutput(json_encode($json));
	}

	public function install(): void
	{
		// Event
		$this->load->model('setting/event');

		$this->model_setting_event->deleteEventByCode('analytics_skroutz');

		$this->model_setting_event->addEvent('analytics_skroutz', '', 'catalog/view/common/success/after', 'extension/skroutz_analytics/analytics/skroutz|loadCheckoutScript', true, 1);
		$this->model_setting_event->addEvent('analytics_skroutz', '', 'catalog/view/product/product/after', 'extension/skroutz_analytics/analytics/skroutz|loadReviewsWidget', true, 1);

		// Permissions
		$this->load->model('user/user_group');

		$this->model_user_user_group->addPermission($this->user->getGroupId(), 'access', 'extension/skroutz_analytics/analytics/skroutz');
		$this->model_user_user_group->addPermission($this->user->getGroupId(), 'modify', 'extension/skroutz_analytics/analytics/skroutz');
	}

	public function uninstall(): void
	{
		// Events
		$this->load->model('setting/event');

		$this->model_setting_event->deleteEventByCode('analytics_skroutz');

		// Permissions
		$this->load->model('user/user_group');

		$this->model_user_user_group->removePermission($this->user->getGroupId(), 'access', 'extension/skroutz_analytics/analytics/skroutz');
		$this->model_user_user_group->removePermission($this->user->getGroupId(), 'modify', 'extension/skroutz_analytics/analytics/skroutz');
	}
}